package com.example.demo;

import java.util.List;

public class DataResponse {

	private List<String> listofRecipe;

	public List<String> getListofRecipe() {
		return listofRecipe;
	}

	public void setListofRecipe(List<String> listRecipe) {
		this.listofRecipe = listRecipe;
	}

	
}
