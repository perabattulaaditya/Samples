package com.example.demo;

public class DataRequest {

	private String recipeid;

	public String getRecipeid() {
		return recipeid;
	}

	public void setRecipeid(String recipeid) {
		this.recipeid = recipeid;
	}

	
}
